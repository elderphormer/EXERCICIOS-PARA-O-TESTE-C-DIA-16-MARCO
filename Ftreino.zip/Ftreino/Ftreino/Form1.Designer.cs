﻿namespace Ftreino
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_modelo = new System.Windows.Forms.Label();
            this.txtb_modelo = new System.Windows.Forms.TextBox();
            this.cbb_auto = new System.Windows.Forms.ComboBox();
            this.lbl_auto = new System.Windows.Forms.Label();
            this.grb_HD = new System.Windows.Forms.GroupBox();
            this.rdb_sim = new System.Windows.Forms.RadioButton();
            this.rdb_nao = new System.Windows.Forms.RadioButton();
            this.ltb_modelo = new System.Windows.Forms.ListBox();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_media = new System.Windows.Forms.Button();
            this.btn_inserir = new System.Windows.Forms.Button();
            this.grb_HD.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_modelo
            // 
            this.lbl_modelo.AutoSize = true;
            this.lbl_modelo.Location = new System.Drawing.Point(12, 33);
            this.lbl_modelo.Name = "lbl_modelo";
            this.lbl_modelo.Size = new System.Drawing.Size(53, 16);
            this.lbl_modelo.TabIndex = 0;
            this.lbl_modelo.Text = "Modelo";
            // 
            // txtb_modelo
            // 
            this.txtb_modelo.Location = new System.Drawing.Point(12, 52);
            this.txtb_modelo.MaxLength = 128;
            this.txtb_modelo.Name = "txtb_modelo";
            this.txtb_modelo.Size = new System.Drawing.Size(228, 22);
            this.txtb_modelo.TabIndex = 1;
            this.txtb_modelo.TextChanged += new System.EventHandler(this.txtb_modelo_TextChanged);
            // 
            // cbb_auto
            // 
            this.cbb_auto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_auto.FormattingEnabled = true;
            this.cbb_auto.Items.AddRange(new object[] {
            "30",
            "60",
            "180",
            "240",
            "300"});
            this.cbb_auto.Location = new System.Drawing.Point(15, 118);
            this.cbb_auto.Name = "cbb_auto";
            this.cbb_auto.Size = new System.Drawing.Size(121, 24);
            this.cbb_auto.TabIndex = 2;
            // 
            // lbl_auto
            // 
            this.lbl_auto.AutoSize = true;
            this.lbl_auto.Location = new System.Drawing.Point(12, 99);
            this.lbl_auto.Name = "lbl_auto";
            this.lbl_auto.Size = new System.Drawing.Size(103, 16);
            this.lbl_auto.TabIndex = 3;
            this.lbl_auto.Text = "Autonomia (min)";
            // 
            // grb_HD
            // 
            this.grb_HD.Controls.Add(this.rdb_sim);
            this.grb_HD.Controls.Add(this.rdb_nao);
            this.grb_HD.Location = new System.Drawing.Point(276, 52);
            this.grb_HD.Name = "grb_HD";
            this.grb_HD.Size = new System.Drawing.Size(147, 78);
            this.grb_HD.TabIndex = 4;
            this.grb_HD.TabStop = false;
            this.grb_HD.Text = "Camera HD";
            // 
            // rdb_sim
            // 
            this.rdb_sim.AutoSize = true;
            this.rdb_sim.Checked = true;
            this.rdb_sim.Location = new System.Drawing.Point(19, 21);
            this.rdb_sim.Name = "rdb_sim";
            this.rdb_sim.Size = new System.Drawing.Size(51, 20);
            this.rdb_sim.TabIndex = 5;
            this.rdb_sim.TabStop = true;
            this.rdb_sim.Text = "Sim";
            this.rdb_sim.UseVisualStyleBackColor = true;
            // 
            // rdb_nao
            // 
            this.rdb_nao.AutoSize = true;
            this.rdb_nao.Location = new System.Drawing.Point(19, 47);
            this.rdb_nao.Name = "rdb_nao";
            this.rdb_nao.Size = new System.Drawing.Size(54, 20);
            this.rdb_nao.TabIndex = 6;
            this.rdb_nao.Text = "Não";
            this.rdb_nao.UseVisualStyleBackColor = true;
            // 
            // ltb_modelo
            // 
            this.ltb_modelo.FormattingEnabled = true;
            this.ltb_modelo.ItemHeight = 16;
            this.ltb_modelo.Location = new System.Drawing.Point(15, 158);
            this.ltb_modelo.Name = "ltb_modelo";
            this.ltb_modelo.Size = new System.Drawing.Size(436, 244);
            this.ltb_modelo.TabIndex = 5;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Enabled = false;
            this.btn_eliminar.Location = new System.Drawing.Point(15, 415);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(75, 23);
            this.btn_eliminar.TabIndex = 6;
            this.btn_eliminar.Text = "Eliminar";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_media
            // 
            this.btn_media.Location = new System.Drawing.Point(376, 415);
            this.btn_media.Name = "btn_media";
            this.btn_media.Size = new System.Drawing.Size(75, 23);
            this.btn_media.TabIndex = 7;
            this.btn_media.Text = "Média";
            this.btn_media.UseVisualStyleBackColor = true;
            // 
            // btn_inserir
            // 
            this.btn_inserir.Enabled = false;
            this.btn_inserir.Location = new System.Drawing.Point(165, 119);
            this.btn_inserir.Name = "btn_inserir";
            this.btn_inserir.Size = new System.Drawing.Size(75, 23);
            this.btn_inserir.TabIndex = 8;
            this.btn_inserir.Text = "Inserir";
            this.btn_inserir.UseVisualStyleBackColor = true;
            this.btn_inserir.Click += new System.EventHandler(this.btn_inserir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 450);
            this.Controls.Add(this.btn_inserir);
            this.Controls.Add(this.btn_media);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.ltb_modelo);
            this.Controls.Add(this.grb_HD);
            this.Controls.Add(this.lbl_auto);
            this.Controls.Add(this.cbb_auto);
            this.Controls.Add(this.txtb_modelo);
            this.Controls.Add(this.lbl_modelo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grb_HD.ResumeLayout(false);
            this.grb_HD.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_modelo;
        private System.Windows.Forms.TextBox txtb_modelo;
        private System.Windows.Forms.ComboBox cbb_auto;
        private System.Windows.Forms.Label lbl_auto;
        private System.Windows.Forms.GroupBox grb_HD;
        private System.Windows.Forms.RadioButton rdb_sim;
        private System.Windows.Forms.RadioButton rdb_nao;
        private System.Windows.Forms.ListBox ltb_modelo;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_media;
        private System.Windows.Forms.Button btn_inserir;
    }
}

