﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ftreino
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbb_auto.SelectedIndex = 3;
        }

        private void txtb_modelo_TextChanged(object sender, EventArgs e)
        {
            if(txtb_modelo.Text != "")
                btn_inserir.Enabled = true;
            else
                btn_inserir.Enabled = false;
        }

        private void btn_inserir_Click(object sender, EventArgs e)
        {
            string nome = txtb_modelo.Text;
            string auto = cbb_auto.SelectedItem.ToString();
            string HD = "";
            string linha = "";


            if (rdb_sim.Checked)
                HD = ".HD";
            else
                HD = "";

            linha = $"{nome}{HD}, ({auto})";

            ltb_modelo.Items.Add(linha);



            txtb_modelo.Text = "";
            txtb_modelo.Focus();
        }
    }
}
